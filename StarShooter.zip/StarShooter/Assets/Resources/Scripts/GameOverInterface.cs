﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameOverInterface : MonoBehaviour {

	//Muestra la puntuación final.
	void Start () {
		GameObject.Find("PuntosText").GetComponent<Text>().text = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<SceneController>().puntuacion.ToString();
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

    bool recargado = true;
	
	//Control de inputs y animaciones.
	void Update () {
		
        if(Input.GetKey(KeyCode.LeftArrow) && transform.position.x > -5.5f || Input.GetKey(KeyCode.A) && transform.position.x > -5.5f)
        {
            transform.position = new Vector2(transform.position.x - 0.2f, transform.position.y);
            playerRotation(0); //left
        }
        else if (Input.GetKey(KeyCode.RightArrow) && transform.position.x < 5.6f || Input.GetKey(KeyCode.D) && transform.position.x < 5.6f)
        {
            transform.position = new Vector2(transform.position.x + 0.2f, transform.position.y);
            playerRotation(1); //right
        }
        else
        {
            transform.rotation = new Quaternion(0, 0, 0, 0);
        }

        if(Input.GetKeyDown(KeyCode.Space) && recargado == true)
        {
            recargado = false;
            GameObject disparo = Instantiate(Resources.Load("Prefabs/PlayerBeam"), new Vector2(transform.position.x, transform.position.y), new Quaternion(0, 0, 0, 0)) as GameObject;
            Invoke("recargaDisparo", 0.5f);
        }

        if (GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).IsName("muerte"))
        {
            if (GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).normalizedTime > 1 && !GetComponent<Animator>().IsInTransition(0))
            {
                Destroy(this.gameObject);
            }
        }

    }

    //Pequeña animación de rotación de la nave.
    private void playerRotation(int dir)
    {   
        if (dir == 0) //left
        {
            if (transform.localEulerAngles.z < 10)
            {
                transform.Rotate(new Vector3(0, 0, 1));
            }
        }
        else if(dir == 1)//right
        {
            if (transform.localEulerAngles.z > 350 && transform.localEulerAngles.z < 360 || transform.localEulerAngles.z == 0)
            {
                transform.Rotate(new Vector3(0, 0, -1));
            }
        }
    }

    //Termina el cooldown del disparo.
    private void recargaDisparo()
    {
        recargado = true;
    }
}

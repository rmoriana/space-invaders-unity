﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ButtonController : MonoBehaviour {

	//Carga la escena de ingame.
	public void iniciaJuego(){
	
		SceneManager.LoadScene ("inGame");
	}
}

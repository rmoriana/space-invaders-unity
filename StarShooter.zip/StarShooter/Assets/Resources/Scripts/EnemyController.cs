﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour {

    public float velocidad;
    bool retrocediendo = false;
    int cuadrante;
    float tiempoDisparo;
    public float tmpMin, tmpMax;
    private Sprite[] spriteAlien;

	//Inicializa el enemigo.
	void Start () {

        spriteAlien = Resources.LoadAll<Sprite>("aliens");
        
        if(transform.position.x > 0)
        {
            cuadrante = 1; //DERECHA
        }
        else
        {
            cuadrante = 0; //IZQUIERDA
        }

        tmpMin = 2;
        tmpMax = 10;

        tiempoDisparo = Random.Range(tmpMin, tmpMax);
        Invoke("disparo", tiempoDisparo);
    }
	
	//Movimiento y destrucción del enemigo.
	void Update () {

        if(cuadrante == 1)
        {
            if (transform.position.x >= 5.5f)
            {
                retrocediendo = true;
            }
            if (transform.position.x <= 0.5f)
            {
                retrocediendo = false;
            }

            if (retrocediendo == true) //Esta en la derecha y va hacía la derecha
            {
                transform.position = new Vector2(transform.position.x - velocidad, transform.position.y);
            }
            else
            {
                transform.position = new Vector2(transform.position.x + velocidad, transform.position.y);
            }
        }
        else
        {
            if (transform.position.x <= -5.5f)
            {
                retrocediendo = true;
            }
            if (transform.position.x >= -0.5f)
            {
                retrocediendo = false;
            }

            if (retrocediendo == true) //Esta en la derecha y va hacía la derecha
            {
                transform.position = new Vector2(transform.position.x + velocidad, transform.position.y);
            }
            else
            {
                transform.position = new Vector2(transform.position.x - velocidad, transform.position.y);
            }
        }

        if (GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).IsName("alienDestruction"))
        {
            if (GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).normalizedTime > 1 && !GetComponent<Animator>().IsInTransition(0))
            {
                Destroy(this.gameObject);
            }
        }

    }

    //Disparo
    private void disparo()
    {
        GameObject shoot = Instantiate(Resources.Load("Prefabs/EnemyBeam"), new Vector2(transform.position.x, transform.position.y), new Quaternion(0, 0, 0, 0)) as GameObject;

        tiempoDisparo = Random.Range(tmpMin, tmpMax);
        Invoke("disparo", tiempoDisparo);
    }
}

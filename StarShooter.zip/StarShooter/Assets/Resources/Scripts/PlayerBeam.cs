﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerBeam : MonoBehaviour {
	
	//El disparo del jugador se mueve hacia arriba y se destruye tras salirse de la pantalla.
	void Update () {
        transform.position = new Vector2(transform.position.x, transform.position.y + 0.1f);
        if(transform.position.y > 6)
        {
            Destroy(this.gameObject);
        }
	}

    //Si colisiona con un enemigo lo destruye, aumenta la velocidad de disparo del resto, suma puntos al jugador y comprueba si el juego ha terminado.
    void OnTriggerEnter2D(Collider2D other)
    {
        string tag = other.gameObject.tag;

        if (tag == "Enemy")
        {
            other.gameObject.GetComponent<Animator>().SetBool("muerto", true);

            //Reduce el tiempo de disparo de los enemigos restantes
            GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");
			if (enemies.Length == 1) { //Ha destruido al último enemigo.
				DestroyAll ();
				SceneManager.LoadScene ("GameOver", LoadSceneMode.Additive);
			} else {
				for (int i = 0; i < enemies.Length; i++)
				{
					enemies[i].GetComponent<EnemyController>().tmpMin -= 0.22f;
					enemies[i].GetComponent<EnemyController>().tmpMax -= 1.1f;
				}                        
			}
            
            
			GameObject.FindGameObjectWithTag ("MainCamera").GetComponent<SceneController> ().puntuacion += 100;
            Destroy(this.gameObject);
        }
    }

    //Destruye todos los elementos al terminar el juego.
	private void DestroyAll(){
		GameObject[] arrayAliens = GameObject.FindGameObjectsWithTag ("Enemy");
		GameObject[] disparosEnemigos = GameObject.FindGameObjectsWithTag ("enemyBeam");
		GameObject[] disparosPlayer = GameObject.FindGameObjectsWithTag ("playerBeam");
		GameObject[] estrellas = GameObject.FindGameObjectsWithTag ("estrella");

		for (int i = 0; i < arrayAliens.Length; i++) {
			Destroy (arrayAliens [i]);
		}
		for (int i = 0; i < disparosEnemigos.Length; i++) {
			Destroy (disparosEnemigos [i]);
		}
		for (int i = 0; i < disparosPlayer.Length; i++) {
			Destroy (disparosPlayer [i]);
		}
		for (int i = 0; i < estrellas.Length; i++) {
			Destroy (estrellas [i]);
		}
	}
}

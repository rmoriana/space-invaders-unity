﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneController : MonoBehaviour {

    int numEstrellas = 100;
	public int puntuacion = 0;

	//Inicia la partida creando las estrellas decorativas y los enemigos.
	void Start () {
        creaEstrellas();
        creaEnemigos();
	}	

    //Crea un fondo aleatorio formado por estrellas de colores.
    private void creaEstrellas()
    {
        GameObject Estrellas = new GameObject();
        Estrellas.name = "Estrellas";
        int color;
        for (int i = 0; i < numEstrellas; i++)
        {
            color = Random.Range(0, 2);
            if(color == 0)
            {
                GameObject estrella = Instantiate(Resources.Load("Prefabs/EstrellaVerde"), new Vector2(Random.Range(-6.0f, 6.0f),Random.Range(-5.0f, 5.0f)), new Quaternion(0, 0, 0, 0)) as GameObject;
                estrella.transform.parent = Estrellas.transform;
            }
            else
            {
                GameObject estrella = Instantiate(Resources.Load("Prefabs/EstrellaAzul"), new Vector2(Random.Range(-6.0f, 6.0f), Random.Range(-5.0f, 5.0f)), new Quaternion(0, 0, 0, 0)) as GameObject;
                estrella.transform.parent = Estrellas.transform;
            }            
        }
    }

    //Inicializa los enemigos y establece su velocidad en función del color.
    private void creaEnemigos()
    {
        float posX = 5.5f;
        float posY = 4.5f;
        int color;

        for (int i = 0; i < 5; i++)
        {
            GameObject alien = Instantiate(Resources.Load("Prefabs/Alien"), new Vector2(posX,posY), new Quaternion(0, 0, 0, 0)) as GameObject;
            GameObject alien2 = Instantiate(Resources.Load("Prefabs/Alien"), new Vector2(-posX, posY), new Quaternion(0, 0, 0, 0)) as GameObject;

            if(i != 4)
            {
                color = i;
            }
            else
            {
                color = 1;
            }
             
            alien.GetComponent<Animator>().SetInteger("color", color);
            alien2.GetComponent<Animator>().SetInteger("color", color);

            alien.GetComponent<EnemyController>().velocidad = 0.01f + (color * 0.02f);
            alien2.GetComponent<EnemyController>().velocidad = 0.01f + (color * 0.02f);

            posX--;
            posY--;
        }
    }
}

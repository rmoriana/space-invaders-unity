﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EnemyBeam : MonoBehaviour {
	
	//El disparo del enemigo va hacia abajo y se destruye cuando sale de la pantalla.
	void Update () {
        transform.position = new Vector2(transform.position.x, transform.position.y - 0.1f);
        if (transform.position.y < -6)
        {
            Destroy(this.gameObject);
        }
    }

    //Si colisiona con el jugador, se acaba el juego.
    void OnTriggerEnter2D(Collider2D other)
    {
        string tag = other.gameObject.tag;

        if(tag == "Player")
        {
            other.gameObject.GetComponent<Animator>().SetBool("playerDeath", true);
            Destroy(this.gameObject);
			DestroyAll ();
			SceneManager.LoadScene ("GameOver", LoadSceneMode.Additive);
        }
    }

    //Lo destruye todo para dejar la escena limpia.
	private void DestroyAll(){
		GameObject[] arrayAliens = GameObject.FindGameObjectsWithTag ("Enemy");
		GameObject[] disparosEnemigos = GameObject.FindGameObjectsWithTag ("enemyBeam");
		GameObject[] disparosPlayer = GameObject.FindGameObjectsWithTag ("playerBeam");
		GameObject[] estrellas = GameObject.FindGameObjectsWithTag ("estrella");

		for (int i = 0; i < arrayAliens.Length; i++) {
			Destroy (arrayAliens [i]);
		}
		for (int i = 0; i < disparosEnemigos.Length; i++) {
			Destroy (disparosEnemigos [i]);
		}
		for (int i = 0; i < disparosPlayer.Length; i++) {
			Destroy (disparosPlayer [i]);
		}
		for (int i = 0; i < estrellas.Length; i++) {
			Destroy (estrellas [i]);
		}
	}


}
